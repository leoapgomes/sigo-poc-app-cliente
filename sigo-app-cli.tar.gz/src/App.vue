<template>


  <div v-if="exibeLogin">
    <transition name="fade">
      <router-view/> 
    </transition>
  </div>
  <div id="main" v-else>
    <div id="menu">
      <center><br/><img src="@/assets/logo.png" /></center>
      <hr/>
      <router-link to="/normas">Gestão de Normas</router-link><br/>
      <router-link to="/consultorias">Consultorias e Assessorias</router-link>      
    </div>
    <div id="content">  
      <transition name="fade">    
        <router-view/> 
      </transition>
    </div>
  </div>


</template>


<script>
export default {
  computed : {
    exibeLogin (){
      return this.$route.fullPath==="/login";
    }
  }
}
</script>


<style>

#main{
  display: grid;
  grid-gap: 0px;
  grid-template-columns: 250px auto;
  height: 100vh;
}

#menu {
  background-image: linear-gradient(#233626, #2f4050);
  text-align: center;
}

#menu a {
  color: white;
  text-decoration: none;
  border: 0px solid red;
  line-height: 40px;  
}

#menu .router-link-active {
  color: bisque;
  font-weight: bold;
}

#content{
  background-color: white;
  margin: 25px;
  border: 1px solid #e7eaec;
}

hr{
  border: 1px solid #e7eaec;
  width: 80%;
}
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.5s ease;
}


.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>
