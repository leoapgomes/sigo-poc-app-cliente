<template>
  <PanelPrincipal titulo="Gestão de Normas">
    <router-link to="/normas-form">Incluir nova norma</router-link>
    <br /><br />
      <table id="table-normas">
        <tr>
          <th width="20%">Norma</th>
          <th width="25%">Título</th>
          <th width="20%">Tipo de Norma</th>
          <th width="30%">Url</th>
          <th width="5%" class="th-acoes">&nbsp;</th>
        </tr>
        <tr v-for="norma in normas" :key="norma.id" class="tr-dados">
          <td>{{}}</td>
          <td>{{norma.descricao}}</td>
          <td>{{}}</td>
          <td>{{}}</td>
          <td>
            <button class="acoes" title="Alterar norma" @click="alterarNorma(norma.id)"><i class="far fa-edit fa-lg"></i></button>
            <button class="acoes" title="Excluir norma" @click="excluirNorma(norma.id)"><i class="fas fa-minus fa-lg"></i></button>             
          </td>
        </tr>
      </table>
  </PanelPrincipal>
</template>

<script>
import Http from "../httpClient";
import PanelPrincipal from "@/components/PanelPrincipal.vue";

export default {
  name: "CadastroDeNormas",
  components: {
    PanelPrincipal,
  },
  methods: {

    alterarNorma : function(id){
      this.$router.push(`/normas-form/${id}`);
    },
    excluirNorma : function(id){
      if(confirm("Deseja excluir o registro?")){
        Http.delete(`/gestaodenormas/normas/${id}`)
          .then((response) => {
            this.normas = this.normas.filter(norma => norma.id!==id);
          });
      }
    }

  },
  data() {
    return {
      normas : []
    }
  },
  created() {
    Http.get("/gestaodenormas/normas")
      .then((response) => response.data)
      .then((data) => this.normas = data);
  },
};
</script>

<style scoped>
#table-normas {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

#table-normas th {
  border: 1px solid #2f4050;
  padding: 8px;
}

#table-normas td {
  border: 1px solid #ddd;
  padding: 8px;
}



#table-normas tr:nth-child(even){background-color: #f2f2f2;}
#table-normas tr:hover {background-color: #fffef1;}

#table-normas th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #2f4050;
  color: white;
}

.acoes{
  width: 35px;
  height: 30px;
  line-height: 30px;
  border: 0px solid;
  background-color: transparent;
  outline: none;
  cursor: pointer;
  color: #2f4050;
}

.th-acoes{
  min-width: 70px;
  max-width: 70px;
}

</style>